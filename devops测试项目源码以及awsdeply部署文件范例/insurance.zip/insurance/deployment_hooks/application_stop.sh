#!/bin/bash
echo "application_stop.sh"
targetRoleName=insurance
currentRoleName=`f2cadm getLocalServer --field=clusterRoleName`
if [ "$currentRoleName" != "$targetRoleName" ];then
    echo ERROR: deploy on wrong server, this component can only be deployed to $targetRoleName servers!
    echo Please select host group $targetRoleName when request code deploy in webconsole!
    exit 1
fi
ps aux | grep apache-tomcat-7.0.68 | grep -v grep | awk '{print "kill -9 " $2}' | bash

ps aux | grep apache-tomcat-7.0.68
