#!/bin/bash
echo "after_install.sh"

