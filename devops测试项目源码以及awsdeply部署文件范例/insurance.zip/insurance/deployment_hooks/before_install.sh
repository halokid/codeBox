#!/bin/bash
echo "before_install.sh"
currentTime=`date "+%Y-%m-%d-%H-%M-%S"`
cp /tomcat/apache-tomcat-7.0.68/webapps/insurance.war /tomcat/apache-tomcat-7.0.68/webapps/insurance.war-bak$currentTime
rm -rf /tomcat/apache-tomcat-7.0.68/webapps/insurance
rm -rf /tomcat/apache-tomcat-7.0.68/webapps/insurance.war
