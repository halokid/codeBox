#!/bin/bash
echo "application_start.sh"
bash /tomcat/apache-tomcat-7.0.68/bin/startup.sh
ps aux | grep apache-tomcat-7.0.68
