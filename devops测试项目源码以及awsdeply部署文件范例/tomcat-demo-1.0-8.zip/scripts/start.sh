service tomcat6 start
