service tomcat6 stop
